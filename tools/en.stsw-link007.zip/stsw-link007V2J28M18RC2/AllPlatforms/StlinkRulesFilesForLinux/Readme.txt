File to copy in /etc/udev/rules.d/ on Ubuntu ("sudo cp *.* /etc/udev/rules.d").

Note that no file is provided for ST-Link/V1 (idProduct=3744) as long as the interfacing
with this device has not been ported on Linux.